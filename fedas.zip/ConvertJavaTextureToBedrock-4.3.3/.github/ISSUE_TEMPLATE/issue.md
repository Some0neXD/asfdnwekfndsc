---
name: Issue
about: Report issue
title: ''
labels: ''
assignees: ''

---

**Describe the issue**
Please consult the readme and other issues before you report an issue

A clear and concise description of what the issue is.

Is there an error message?

Which step is previous the error message?

Is it the same error/step or is different if you try multiple times?

Are the textures available/correct on Java version?

**System info**

***Converting***
System OS: 
Browser: 

***Game***
System OS: 

**Texture pack**
Link to download: 
