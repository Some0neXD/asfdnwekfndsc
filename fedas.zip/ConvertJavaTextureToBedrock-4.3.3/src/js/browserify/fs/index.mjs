function existsSync() {

}

export {existsSync};
