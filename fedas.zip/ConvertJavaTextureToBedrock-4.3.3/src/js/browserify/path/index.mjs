import path from "path-browserify"; // Latest version which supports `path.parse`

const {basename, dirname, join, parse, sep} = path;

export {basename, dirname, join, parse, sep};
